package ney.AbstractVsInterface;

import java.awt.Color;

public interface Colorful {

	void setColor(Color color);

	Color getColor();

}
