package ney.dogdoor;

public class Cat {

}
