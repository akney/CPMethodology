package ney.dogdoor;

import java.util.ArrayList;

public class DogDoor {
	private boolean open;
	private ArrayList<Dog> dogsAllowedEntry;

	public DogDoor() {
		open = false;
		dogsAllowedEntry = new ArrayList<Dog>(5);

	}

	public boolean checkIfOpen() {
		return open;
	}

	public void setOpen(boolean open) {
		this.open = open;
	}

	public void openWithBark(String bark) {
		for (Dog dog : dogsAllowedEntry) {
			if (dog.getBark().equals(bark)) {
				open = true;
				return;
			}
		}

		open = false;
	}

	public void openWithPaw(String paw) {
		for (Dog dog : dogsAllowedEntry) {
			if (dog.getPaw().equals(paw)) {
				open = true;
				return;
			}
		}

		open = false;
	}

	public void animalEntering(Object animal) {
		if (!(animal instanceof Dog)) {
			open = false;
		}
	}
}
