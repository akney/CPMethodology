package ney.dogdoor;

public class Dog {
	private String bark;
	private String paw;

	public Dog(String bark, String paw) {
		this.bark = bark;
		this.paw = paw;
	}

	public String getBark() {
		return bark;
	}

	public String getPaw() {
		return paw;
	}
}
